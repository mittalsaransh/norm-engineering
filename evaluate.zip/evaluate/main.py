import json
from src.config import Config
from src.validator import LabelValidator

def main():
    Config.setup_env()
    validator = LabelValidator()
    
    try:
        with open(Config.JSON_PATH) as f:
            json_data = json.load(f)
        with open(Config.REGULATION_PATH) as f:
            regulation_text = f.read()
        
        validation_result = validator.validate(regulation_text, json_data)
        
        print("\nValidation Results:")
        print(json.dumps(validation_result, indent=2))
            
    except Exception as e:
        print(f"Error: {str(e)}")

if __name__ == "__main__":
    main()
