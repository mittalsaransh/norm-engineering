import os

class Config:
    JSON_PATH = './data/output_orc_4709.12.json'
    REGULATION_PATH = './data/regulation.txt'
    KEY_PATH = './key.txt'

    @staticmethod
    def get_api_key():
        try:
            with open(Config.KEY_PATH, 'r') as f:
                return f.read().strip()
        except Exception as e:
            raise Exception(f"Failed to read API key from {Config.KEY_PATH}: {str(e)}")

    @staticmethod
    def setup_env():
        os.environ["OPENAI_API_KEY"] = Config.get_api_key()
