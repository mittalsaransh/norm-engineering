LABEL_CONFIG = {
    'acts': {
        'focus': 'regulatory actions and permissions',
        'entity_type': 'acts/actions/permissions',
        'considerations': [
            'Explicit permissions granted',
            'Actions that can be performed',
            'Transactions or processes mentioned'
        ]
    },
    'facts': {
        'focus': 'conditions and requirements',
        'entity_type': 'facts/conditions',
        'considerations': [
            'Monetary amounts and thresholds',
            'Time periods and deadlines',
            'Qualifying conditions',
            'State requirements'
        ]
    },
    'duties': {
        'focus': 'obligations and responsibilities',
        'entity_type': 'duties/obligations',
        'considerations': [
            'Mandatory requirements',
            'Legal obligations',
            'Required actions',
            'Compliance requirements'
        ]
    },
    'agents': {
        'focus': 'entities and stakeholders',
        'entity_type': 'agents/entities',
        'considerations': [
            'Organizations mentioned',
            'Roles and positions',
            'Government bodies',
            'Other stakeholders'
        ]
    }
}

from langchain.prompts import PromptTemplate

def _create_validation_prompt(label_type: str) -> PromptTemplate:
    config = LABEL_CONFIG[label_type]
    template = f"""
    As a legal expert focusing on {config['focus']}, analyze this regulation:
    
    {{regulation_text}}
    
    Currently identified {config['entity_type']}:
    {{labels}}
    
    List any missing {label_type}, considering:
    {chr(10).join(f'{i+1}. {item}' for i, item in enumerate(config['considerations']))}
    
    Return response as a JSON array of strings containing only the missing {label_type}.
    """
    return PromptTemplate(input_variables=["regulation_text", "labels"], template=template)
