from langchain.chains import LLMChain
from langchain_community.llms import OpenAI
from langchain.prompts import PromptTemplate
import json
from typing import Union, List, Dict
from src.prompts import LABEL_CONFIG, _create_validation_prompt

class LabelValidator:
    def __init__(self):
        self.llm = OpenAI(temperature=0)

    def extract_labels(self, json_data: Union[str, dict], field: str) -> List[str]:
        try:
            if isinstance(json_data, str):
                json_data = json.loads(json_data)
            return [item["label"] for item in json_data.get(field, []) if "label" in item]
        except Exception as e:
            print(f"Error extracting labels: {str(e)}")
            return []

    def validate(self, regulation_text: str, json_data: Dict) -> Dict:
        all_labels = []
        for label_type in LABEL_CONFIG.keys():
            labels = self.extract_labels(json_data, label_type)
            all_labels.extend([{"type": label_type, "label": label} for label in labels])

        return self._validate_labels(regulation_text, all_labels)

    def _group_labels_by_type(self, labels: List[dict]) -> dict:
        result = {}
        for label in labels:
            if label["type"] not in result:
                result[label["type"]] = []
            result[label["type"]].append(label["label"])
        return result

    def _validate_category(self, regulation_text: str, current_labels: List[str], 
                         prompt_template: PromptTemplate) -> List[str]:
        chain = LLMChain(llm=self.llm, prompt=prompt_template)
        formatted_labels = "\n".join(f"- {label}" for label in current_labels)
                
        try:
            result = chain.run(regulation_text=regulation_text, labels=formatted_labels)
            missing_labels = json.loads(result)

            return [label for label in missing_labels if label not in current_labels]
        except Exception as e:
            print(f"Error in validation: {str(e)}")
            return []
        
    def _validate_labels(self, regulation_text: str, extracted_labels: List[dict]) -> dict:
        labels_by_type = self._group_labels_by_type(extracted_labels)        
        return {
            label_type: {
                "original": labels_by_type.get(label_type, []),
                "missing": self._validate_category(
                    regulation_text,
                    labels_by_type.get(label_type, []),
                    _create_validation_prompt(label_type)
                )
            }
            for label_type in LABEL_CONFIG.keys()
        }
